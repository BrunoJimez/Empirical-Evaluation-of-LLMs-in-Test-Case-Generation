import unittest
from binarySearchTree2 import BST


class TestBST(unittest.TestCase):
    def setUp(self):
        self.tree = BST()

    def test_add_contains(self):
        self.tree.add(3)
        self.tree.add(2)
        self.tree.add(4)
        self.assertTrue(self.tree.contains(3))
        self.assertTrue(self.tree.contains(2))
        self.assertTrue(self.tree.contains(4))
        self.assertFalse(self.tree.contains(1))

    def test_remove(self):
        self.tree.add(3)
        self.tree.add(2)
        self.tree.add(4)
        self.tree.remove(2)
        self.assertFalse(self.tree.contains(2))
        self.assertEqual(len(self.tree), 2)

    def test_build(self):
        self.tree.build([1, 2, 3])
        self.assertTrue(self.tree.contains(1))
        self.assertTrue(self.tree.contains(2))
        self.assertTrue(self.tree.contains(3))

    def test_get_order(self):
        self.tree.build([1, 2, 3])
        self.assertEqual(self.tree.getOrder("inOrder"), [1, 2, 3])
        self.assertEqual(self.tree.getOrder("preOrder"), [2, 1, 3])
        self.assertEqual(self.tree.getOrder("postOrder"), [1, 3, 2])

    def test_str(self):
        self.tree.build([1, 2, 3])
        self.assertEqual(str(self.tree), "[1, 2, 3]")

if __name__ == "__main__":
    unittest.main()
