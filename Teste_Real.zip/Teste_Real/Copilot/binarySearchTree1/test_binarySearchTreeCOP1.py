import unittest

from binarySearchTree1 import BinaryNode, BinaryTree

class TestBinaryTree(unittest.TestCase):
    def setUp(self):
        self.tree = BinaryTree()
        self.tree.add(5)
        self.tree.add(3)
        self.tree.add(7)
        self.tree.add(2)
        self.tree.add(4)

    def test_add(self):
        self.assertTrue(5 in self.tree)
        self.assertTrue(3 in self.tree)
        self.assertTrue(7 in self.tree)
        self.assertTrue(2 in self.tree)
        self.assertTrue(4 in self.tree)
        self.assertFalse(1 in self.tree)

    def test_remove(self):
        self.tree.remove(3)
        self.assertFalse(3 in self.tree)
        self.assertTrue(2 in self.tree)
        self.assertTrue(4 in self.tree)

    def test_get_min_max(self):
        self.assertEqual(self.tree.getMin(), 2)
        self.assertEqual(self.tree.getMax(), 7)

    def test_closest(self):
        self.assertEqual(self.tree.closest(1), 2)
        self.assertEqual(self.tree.closest(8), 7)

if __name__ == '__main__':
    unittest.main()

