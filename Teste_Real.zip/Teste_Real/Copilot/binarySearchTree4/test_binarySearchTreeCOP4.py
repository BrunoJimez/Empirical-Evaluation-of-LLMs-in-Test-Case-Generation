import unittest
from binarySearchTree4 import Bst


class TestBst(unittest.TestCase):
    def test_insert_root(self):
        bst = Bst()
        root = bst.insert(10)
        self.assertEqual(root.data, 10)

    def test_insert_left(self):
        bst = Bst()
        root = bst.insert(10)
        left_child = bst.insert(5)
        self.assertEqual(root.left, left_child)

    def test_insert_right(self):
        bst = Bst()
        root = bst.insert(10)
        right_child = bst.insert(15)
        self.assertEqual(root.right, right_child)

    def test_insert_duplicate(self):
        bst = Bst()
        root = bst.insert(10)
        duplicate = bst.insert(10)
        self.assertEqual(duplicate, root.left)

if __name__ == '__main__':
    unittest.main()

