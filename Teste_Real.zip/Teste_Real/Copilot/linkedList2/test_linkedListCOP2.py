

import unittest

from linkedList2 import LinkedList, LinkedNode

class TestLinkedNode(unittest.TestCase):
    def test_checkInfinite(self):
        # Teste para verificar se há um loop infinito
        node1 = LinkedNode(1)
        node2 = LinkedNode(2)
        node3 = LinkedNode(3)
        node1.next = node2
        node2.next = node3
        node3.next = node1  # Cria um loop infinito
        self.assertTrue(node1.checkInfinite())

    def test_checkNotInfinite(self):
        # Teste para verificar que não há loop infinito
        node1 = LinkedNode(1)
        node2 = LinkedNode(2)
        node3 = LinkedNode(3)
        node1.next = node2
        node2.next = node3
        self.assertFalse(node1.checkInfinite())

class TestLinkedList(unittest.TestCase):
    def test_prepend(self):
        # Teste para verificar a função prepend
        ll = LinkedList()
        ll.prepend(1)
        ll.prepend(2)
        self.assertEqual(str(ll), 'link:[2,1]')

    def test_pop(self):
        # Teste para verificar a função pop
        ll = LinkedList(1, 2, 3)
        

    def test_remove(self):
        # Teste para verificar a função remove
        ll = LinkedList(1, 2, 3)
        ll.remove(2)

    def test_len(self):
        # Teste para verificar a função __len__
        ll = LinkedList(1, 2, 3)
        self.assertEqual(len(ll), 3)

if __name__ == '__main__':
    unittest.main()


