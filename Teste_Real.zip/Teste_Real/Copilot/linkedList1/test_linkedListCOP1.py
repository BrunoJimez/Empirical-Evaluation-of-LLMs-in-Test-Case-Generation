import unittest
from linkedList1 import SinglyLinkedList

class TestSinglyLinkedList(unittest.TestCase):
    def setUp(self):
        # Crie uma nova lista antes de cada teste
        self.sll = SinglyLinkedList()

    def test_append(self):
        # Teste se a lista está vazia inicialmente
        self.assertEqual(len(self.sll), 0)

        # Adicione alguns elementos
        self.sll.append(2)
        self.sll.append(3)
        self.sll.append(4)

        # Verifique se o tamanho da lista está correto
        self.assertEqual(len(self.sll), 3)

    def test_getitem(self):
        self.sll.append(2)
        self.sll.append(3)
        self.sll.append(4)

        # Verifique se os índices retornam os valores corretos
        self.assertEqual(self.sll[0], 2)
        self.assertEqual(self.sll[1], 3)
        self.assertEqual(self.sll[2], 4)
        

    def test_setitem(self):
        self.sll.append(2)
        self.sll.append(3)
        self.sll.append(4)

        # Altere os valores em índices específicos
        self.sll[0] = 10
        self.sll[1] = 20

        self.assertEqual(self.sll[0], 10)
        self.assertEqual(self.sll[1], 20)

if __name__ == '__main__':
    unittest.main()


