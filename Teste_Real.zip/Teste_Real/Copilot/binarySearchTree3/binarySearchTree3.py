"""Python implementation of Binary Search Tree."""


class NodeDLL(object):
   
    def __init__(self, data=None, next_node=None, prev=None):
        self.data = data
        self.next = next_node
        self.prev = prev

    def __repr__(self):
        return "Value: {}".format(self.data)


class DoubleLinkedList(object):
   
    def __init__(self, data=None):
        """Initialize list."""
        self.head = None
        self.tail = None
        self._length = 0
        try:
            for val in data:
                self.push(val)
        except TypeError:
            if data:
                self.push(data)

    def push(self, val):
        old_head = self.head
        self.head = NodeDLL(val, next_node=old_head)
        if old_head:
            old_head.prev = self.head
        if not self.tail:
            self.tail = self.head
        self._length += 1

    def pop(self):
        to_return = self.head
        if self._length < 1:
            raise IndexError('Cannot pop from an empty list.')

        new_head = self.head.next
        if new_head:
            new_head.prev = None
        self.head = new_head
        self._length -= 1
        if self._length < 1:
            self.tail = None
        return to_return.data

    def append(self, val):
        old_tail = self.tail
        self.tail = NodeDLL(val, prev=old_tail)
        if old_tail:
            old_tail.next = self.tail
        if self._length < 1:
            self.head = self.tail
        self._length += 1

    def shift(self):
        to_return = self.tail
        if self._length < 1:
            raise IndexError('Cannot shift from an empty list.')

        new_tail = self.tail.prev
        if new_tail:
            new_tail.next = None
        self.tail = new_tail
        self._length -= 1
        if self._length < 1:
            self.tail = None
        return to_return.data

    def remove(self, val):
        curr = self.head
        while curr:
            if curr.data is val:
                if self._length == 1:
                    self.head, self.tail = None, None
                elif curr is not self.head and curr is not self.tail:
                    curr.next.prev, curr.prev.next = curr.prev, curr.next
                elif curr is self.head:
                    self.head, curr.next.prev = curr.next, None
                elif curr is self.tail:
                    self.tail, curr.prev.next = curr.prev, None
                self._length -= 1
                return
            curr = curr.next

        raise ValueError('{} is not in the list'.format(val))

    def _repr(self):
        l = []
        while True:
            try:
                popped_data = self.pop()
                l.append(popped_data)
            except IndexError:
                break
        return l

class Queue(object):
   

    def __init__(self, data=None):
        self._container = DoubleLinkedList(data)

    def enqueue(self, val):
        self._container.append(val)

    def dequeue(self):
        return self._container.pop()

    def peek(self):
        try:
            return self._container.head.data
        except AttributeError:
            return None

    def size(self):
        return self._container._length

class Node(object):

    def __init__(self, val=None, parent=None):
        self.val = val
        self.right = None
        self.left = None
        self.parent = parent
        self.height = 1

    def _is_leaf(self):
        return not (self.right or self.left)

    def _is_interior(self):
        return (self.right and self.left)

    def _onlychild(self):
        if self.left and not self.right:
            return 'left'
        if self.right and not self.left:
            return 'right'

    def _side(self):
        if self.parent:
            return 'left' if self.parent.left == self else 'right'


class Bst(object):

    def __init__(self, data=None):
        self._size = 0
        self.root = None

        if data:
            for i in data:
                self.insert(i)

    def insert(self, val):
        if not self.root:
            self.root = Node(val)
            self._size += 1
        else:
            self._step(val, self.root)

    def _step(self, val, curr):
        if val < curr.val:
            curr = self._set_child(curr, 'left', val)
        elif val > curr.val:
            curr = self._set_child(curr, 'right', val)
        return curr.height

    def _set_child(self, curr, side, val):
        child = getattr(curr, side)
        if child:
            count = self._step(val, child)
            if curr.height <= count:
                curr.height += 1
        else:
            setattr(curr, side, Node(val, curr))
            self._size += 1
            if curr.height == 1:
                curr.height += 1
        return curr

    def search(self, val):
        curr = self.root
        while curr:
            if curr.val == val:
                return curr
            elif val < curr.val:
                curr = curr.left
            else:
                curr = curr.right

    def size(self):
        return self._size

    def depth(self):
        return 0 if not self.root else self.root.height

    def contains(self, val):
        return self.search(val) is not None

    def balance(self, tree=None):
        if not tree:
            tree = self.root
            if not tree:
                return 0

        leftbranch = 0 if not tree.left else tree.left.height
        rightbranch = 0 if not tree.right else tree.right.height

        return leftbranch - rightbranch

    def pre_order(self, node='root'):
        if node == 'root':
            node = self.root

        if not node:
            return

        yield node.val

        for n in self.pre_order(node=node.left):
            yield n
        for n in self.pre_order(node=node.right):
            yield n

    def in_order(self, node='root'):
        if node == 'root':
            node = self.root

        if not node:
            return

        for n in self.in_order(node=node.left):
            yield n
        yield node.val
        for n in self.in_order(node=node.right):
            yield n

    def post_order(self, node='root'):
        if node == 'root':
            node = self.root

        if not node:
            return

        for n in self.post_order(node=node.left):
            yield n
        for n in self.post_order(node=node.right):
            yield n
        yield node.val

    def breadth_first(self):
        q = Queue()
        q.enqueue(self.root)
        while q.peek():
            node = q.dequeue()
            yield node.val
            if node.left:
                q.enqueue(node.left)
            if node.right:
                q.enqueue(node.right)

    def delete(self, val):
        if self._size < 1 or not self.contains(val):
            return

        node = self.search(val)

        if node._is_leaf():  # no children
            if node.parent:
                setattr(node.parent, node._side(), None)
            else:
                self.root = None

        elif node._is_interior():  # two children
            next_node = self._find_replacement(node)
            self._size += 1
            self.delete(next_node.val)
            node.val = next_node.val

        else:  # one children
            child = getattr(node, node._onlychild())
            if node.parent:
                child.parent = node.parent
                setattr(node.parent, node._side(), child)
            else:
                self.root = child

        self._size -= 1

    def _find_replacement(self, node):
        if node.right:
            return self._findmin(node.right)
        else:
            if node.parent:
                if node._side() == 'left':
                    return self.parent
                else:
                    node.parent.right = None
                    tmp = self._find_replacement(node.parent)
                    node.parent.right = node
                    return tmp

    def _findmin(self, node):
        while node.left:
            node = node.left
        return node
