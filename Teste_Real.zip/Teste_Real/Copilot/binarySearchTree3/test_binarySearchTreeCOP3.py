
import unittest
from binarySearchTree3 import DoubleLinkedList, Queue, Node, Bst

class TestDoubleLinkedList(unittest.TestCase):
    def test_push_pop(self):
        dll = DoubleLinkedList()
        dll.push(1)
        dll.push(2)
        self.assertEqual(dll.pop(), 2)
        self.assertEqual(dll.pop(), 1)

    def test_append_shift(self):
        dll = DoubleLinkedList()
        dll.append(1)
        dll.append(2)
        self.assertEqual(dll.shift(), 2)

    # Adicione mais testes conforme necessário

class TestQueue(unittest.TestCase):
    def test_enqueue_dequeue(self):
        q = Queue()
        q.enqueue(1)
        q.enqueue(2)
        self.assertEqual(q.dequeue(), 1)
        self.assertEqual(q.dequeue(), 2)

    # Adicione mais testes conforme necessário

class TestNode(unittest.TestCase):
    def test_is_leaf(self):
        leaf = Node(1)
        self.assertTrue(leaf._is_leaf())
        interior = Node(2)
        interior.left = Node(3)
        self.assertFalse(interior._is_leaf())

    # Adicione mais testes conforme necessário

class TestBst(unittest.TestCase):
    def test_insert_search(self):
        bst = Bst()
        bst.insert(5)
        bst.insert(3)
        self.assertTrue(bst.contains(5))
        self.assertTrue(bst.contains(3))

    # Adicione mais testes conforme necessário

if __name__ == '__main__':
    unittest.main()

