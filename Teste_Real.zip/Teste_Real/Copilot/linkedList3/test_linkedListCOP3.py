import unittest
from linkedList3 import SinglyLinkedList

class TestSinglyLinkedList(unittest.TestCase):
    def test_add_single_element(self):
        linked_list = SinglyLinkedList()
        linked_list.add(42)
        self.assertEqual(linked_list.toArray(), [42])

    def test_add_multiple_elements(self):
        linked_list = SinglyLinkedList()
        linked_list.add(10)
        linked_list.add(20)
        linked_list.add(30)
        self.assertEqual(linked_list.toArray(), [30, 20, 10])

    def test_remove_empty_list(self):
        linked_list = SinglyLinkedList()
        self.assertIsNone(linked_list.remove())

    def test_remove_single_element(self):
        linked_list = SinglyLinkedList()
        linked_list.add(99)
        removed_node = linked_list.remove()
        self.assertEqual(removed_node.value, 99)
        

    def test_get_head(self):
        linked_list = SinglyLinkedList()
        linked_list.add(5)
        linked_list.add(15)
        self.assertEqual(linked_list.getHead(), 15)

    def test_is_empty(self):
        linked_list = SinglyLinkedList()
        self.assertTrue(linked_list.isEmpty())
        linked_list.add(7)
        self.assertFalse(linked_list.isEmpty())

if __name__ == "__main__":
    unittest.main()
