import unittest
from identifier1 import Identifier

class TestIdentifier(unittest.TestCase):
    def test_valid_identifier(self):
        assert Identifier().validateIdentifier("abc123") == True

    def test_invalid_empty_identifier(self):
        assert Identifier().validateIdentifier("") == False

    def test_invalid_long_identifier(self):
        assert Identifier().validateIdentifier("abcdefghi") == False

    def test_invalid_starting_character(self):
        assert Identifier().validateIdentifier("1abc") == False

    def test_invalid_subsequent_character(self):
        assert Identifier().validateIdentifier("a@b") == False

if __name__ == '__main__':
    unittest.main()
